import sys
from cx_Freeze import setup, Executable

''' sous windows lancer  python SetUpFreeze bdist_msi
' sous linux bdist_rpm
' sous mac bdist_mac'''
base=None
if sys.platform == "win32":
    base = "Win32GUI"

path = sys.path

options = {"path":path,
           "include_files":['/home/era23/Documents/aperodedenis/logoCerema.jpg','/home/era23/Documents/aperodedenis/logoIGN.jpg']}
                               
setup(  name = "AperoDeDenis",
        executables = [Executable("/home/era23/Documents/aperodedenis/AperoDeDenis.py")], # ,base = base
        icon="/home/era23/Documents/aperodedenis/logoCerema.jpg",
        author='Denis Jouin',
        version='2.20',
        author_email='denis.jouin@cerema.fr',
        options ={'build_exe':options}
        )
