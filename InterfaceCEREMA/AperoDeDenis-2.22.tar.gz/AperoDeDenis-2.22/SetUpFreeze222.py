import sys
from cx_Freeze import setup, Executable

''' sous windows lancer  python SetUpFreeze bdist_msi
' sous linux
' python3 SetUpCxFreeze.py bdist_rpm
' sous mac bdist_mac'''
base=None
if sys.platform == "win32":
    base = "Win32GUI"

path = sys.path

options = {"path":path,
           "include_files":['/home/era23/Documents/aperodedenis/diffusionv222/logoCerema.jpg',
				'/home/era23/Documents/aperodedenis/diffusionv222/logoIGN.jpg']}
print(options)                               
setup(  name = "AperoDeDenis",
        executables = [Executable("/home/era23/Documents/aperodedenis/diffusionv222/AperoDeDenis.py")], # ,base = base
        author='Denis Jouin',
        version='2.22',
        author_email='interface-micmac@cerema.fr',
        options ={'build_exe':options}
        )
